#include <iostream>
#include "Fresher.h"
#include "Student.h"

char selectMenu()
{

}

int main()
{
	Fresher C03;

	system("pause");
	return 0;
}